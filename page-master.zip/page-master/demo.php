<?php
require 'vendor/autoload.php';
echo \houdunwang\page\Page::make( 100 );
